<p align="center">
  <img src="https://img.shields.io/badge/1C:Предприятие-MCP_Сервер-yellow?style=for-the-badge&logo=1c&logoColor=white" alt="1C MCP" />
  <img src="https://img.shields.io/badge/Memgraph-Графовая_БД-6B4FBB?style=for-the-badge&logo=memgraph&logoColor=white" alt="Memgraph" />
  <img src="https://img.shields.io/badge/Python-3.12-3776AB?style=for-the-badge&logo=python&logoColor=white" alt="Python" />
  <img src="https://img.shields.io/badge/ONNX-Semantic_Search-005CED?style=for-the-badge&logo=onnx&logoColor=white" alt="ONNX" />
  <img src="https://img.shields.io/badge/Docker-Compose-2496ED?style=for-the-badge&logo=docker&logoColor=white" alt="Docker" />
</p>

<h1 align="center">1C Litecode MCP</h1>

<p align="center">
  <b>Граф знаний вашей 1С для AI-ассистентов — локально, без LLM, в одном Docker-контейнере</b><br/>
  <sub>Memgraph + ONNX E5 + sqlite-vec — индексирует ERP с 638&nbsp;000 рутин на 2.5 ГБ RAM</sub>
</p>

<p align="center">
  <a href="https://www.youtube.com/@svhovvv">
    <img src="https://img.shields.io/badge/YouTube-Подписаться_на_канал-FF0000?style=for-the-badge&logo=youtube&logoColor=white" alt="YouTube @svhovvv" />
  </a>
</p>

---

## Если коротко

Ваш AI-ассистент (Claude Code, Cursor, Windsurf, Cline — любой с поддержкой MCP) знает каждый справочник, документ, регистр, реквизит, форму, роль, процедуру и связь между ними **в вашей конфигурации 1С**. Без LLM, без облака, без отправки кода наружу. Локально, в одном `docker compose up`.

```text
Вы:    "Где формируются проводки по зарплате?"
Claude: → search_by_embedding "формирование проводок по зарплате"
        → НачислениеЗарплаты.МодульМенеджера.СформироватьДвижения()
        → score 0.87
        Открываю модуль...
```

И всё это работает на конфигурациях, где **638&nbsp;000 BSL-рутин**, **21&nbsp;000 объектов метаданных** и **20+ ГБ исходников** — без OOM, без зависаний, с возможностью продолжить индексацию после рестарта.

---

## Зачем это нужно

1С — это миры на сотни тысяч строк BSL, тысячи объектов метаданных, перекрёстных ссылок и форм. AI-ассистенты в этом мире **слепы**: они не понимают, какой реквизит у какого справочника, кто кого вызывает и где формируются движения. Каждый запрос «найди где обрабатывается такой-то документ» превращается в час чтения логов и ручных Cypher-запросов.

**1C Litecode MCP** решает это так:

- **Парсит** отчёт по конфигурации, BSL-исходники, формы, роли, GUID-маппинг — за минуты
- **Складывает** всё в граф Memgraph (объекты, реквизиты, вызовы, ссылки `USED_IN` и `MOVEMENTS_IN`)
- **Индексирует** семантически через E5-base + cross-encoder ONNX-модели локально, без API
- **Отдаёт** ассистенту через MCP-протокол два инструмента: структурный (граф) и семантический (embeddings)

Никаких токенов в облако. Никаких подписок. Один контейнер — один проект.

---

## Что отличает Lite от обычных решений

### vs Neo4j + sentence-transformers (PyTorch)

| Компонент | Neo4j + PyTorch | **Lite (Memgraph + ONNX)** | Экономия |
|:----------|:---------------:|:--------------------------:|:--------:|
| Графовая БД | 1200 — 1500 МБ (JVM) | **100 — 500 МБ** (C++) | 3 — 5x |
| Embedding runtime | ~600 МБ (torch) | **~60 МБ** (onnxruntime) | 10x |
| Модель в RAM | ~900 МБ (FP32) | **~400 МБ** (FP16) | 2x |
| Хранение векторов | В heap БД | **sqlite-vec (на диске)** | 0 МБ RAM |
| Docker image | ~3.5 ГБ | **~1.4 ГБ** | 2.5x |
| **2 проекта + БД** | **~12 ГБ** | **~5 ГБ** | **2.5x** |

### Скорость

| Этап | Neo4j + PyTorch | **Lite** |
|:-----|:---------------:|:--------:|
| БД готова к запросам | 30 — 45 сек | **2 — 5 сек** |
| Загрузка средней конфигурации (~8000 объектов) | 5 — 20 мин | **1 — 3 мин** |
| MCP-сервер принимает запросы | после загрузки | **сразу** (load в фоне) |
| Embedding query | ~80 мс | **~50 мс** |

### Стабильность

| Проблема | Neo4j + PyTorch | **Lite** |
|:---------|:---------------:|:--------:|
| JVM crash / OOM | бывает | нет JVM |
| `docker stop` зависает | часто | никогда |
| Transaction timeout на 5 сервисах | да | нет (C++) |
| OOM на больших базах при индексации | гарантированно | **streaming + resume** |

---

## Демо за 60 секунд

```bash
git clone https://github.com/svhov/1c-litecode-mcp.git
cd 1c-litecode-mcp/lite

# Скопировать шаблон compose и подставить свои пути
cp docker-compose.example.yml docker-compose.yml
$EDITOR docker-compose.yml

# Запустить
docker compose build
docker compose up -d memgraph
docker compose up -d litecode-my_project

# Подключить к Claude Code
claude mcp add my_project --transport sse http://localhost:6004/sse
```

Через 30 секунд после запуска MCP-сервер **уже отвечает на запросы**, пока в фоне грузятся данные. Через несколько минут доступен полнотекстовый и семантический поиск.

```text
> /mcp my_project browse Контрагент
{
  "found": [
    {"name": "Контрагенты", "category": "Справочники", "qn": "my_project/Конфигурация/Справочники/Контрагенты"},
    {"name": "КонтрагентыКонтактныеЛица", ...}
  ]
}

> /mcp my_project search_by_embedding "справочник для хранения банковских счетов"
{
  "results": [
    {"name": "БанковскиеСчета", "category": "Справочники", "score": 0.91},
    {"name": "СчетаОрганизаций", "category": "Справочники", "score": 0.74}
  ]
}
```

Ваш AI-ассистент теперь **знает каждый угол** вашей конфигурации.

---

## Что нового

### 2026-04-12 — Enriched embedding search v2

Полная переработка семантического поиска. Precision@1 поднят с 43% до **75%** на конфигурации 92K рутин. P@3 = **95%**, P@5 = **100%**.

**Обогащение текста объектов (15 полей):**

```text
Тип: Регистр сведений
Имя: Цены Номенклатуры
Синоним: Цены номенклатуры
Назначение: хранение цен и тарифов
Подсистема: Ценообразование
Измерения: Номенклатура, Характеристика, Вид Цены
Ресурсы: Цена, Валюта
Реквизиты: Дата Действия, Автор
Связан с: Справочник.Номенклатура, Справочник.ВидыЦен
Используется в: РеализацияТоваровУслуг, ЗаказКлиента
Регистраторы: УстановкаЦенНоменклатуры
Формы: ФормаЗаписи, ФормаСписка
Экспортные процедуры: ПолучитьЦену, УстановитьЦену
Контекст: актуальные цены товаров прайс-лист
```

**Обогащение текста процедур (10 полей):**

```text
Модуль: CommonModules.СкидкиНаценкиСервер
Тип модуля: ОбщийМодуль
Процедура ПрименитьРезультатРасчета(Объект, Скидки) Экспорт
Контекст: НаСервере
Область: ПрограммныйИнтерфейс
Описание: Применяет результат расчета скидок к документу
Событие: ОбработкаПроведения
Параметры: Объект - ДокументОбъект, Скидки - Массив
Возвращает: Булево
Работает с: Документы.ЗаказКлиента, РегистрыСведений.СкидкиНаценки
```

**Hybrid scoring fixes:**
- BM25-only кандидаты получают полный score (не 15% как раньше)
- Русский стемминг в FTS5 (strip суффиксов -ов, -ами, -ей...)
- Exact name match boost для коротких объектов (2x)
- Object tiebreaker boost в search_all (1.05x / 1.5x)
- Query expansion: 18 доменных синонимов
- Фильтр по категории: `{"category": "РегистрыСведений"}`
- Cross-enrichment: ключевые слова из описаний связанных рутин
- Парсинг подсистем из `Состав:` в отчёте по конфигурации
- Переименование `DO_MOVEMENTS_IN` -> `MOVEMENTS_IN`

**Benchmark-результаты:**

| Сервер | Объектов | Рутин | P@1 | P@3 | P@5 | MRR |
|--------|---------|-------|-----|-----|-----|-----|
| DO_AME | 201 | 927 | **80%** | 80% | 100% | 0.84 |
| DO_MAIN | 5981 | 91826 | **65%** | 90% | 95% | 0.78 |

### 2026-04 — Streaming embedding pipeline

- **Bounded RAM** — embed -> flush -> free чанками по 2000 рутин, peak ~2.5 ГБ
- **Resumable** — каждый чанк сразу в `embeddings.db`, restart продолжает с места обрыва
- **Адаптивный batch_size** — уменьшается при длинных текстах (64 -> 32 -> 16)
- **Bulk-commit** — `add_many()` пишет чанк за одну транзакцию

### 2026-04 — Heartbeat и прочее

- **SSE Ping** (10s) + **Heartbeat** (30s, только после индексации)
- **Batched GUID writes** — пачками по 500, минуты вместо часов
- **`docker-compose.example.yml`** — шаблон с комментариями, `docker-compose.yml` в `.gitignore`

---

## Benchmark & Testing

Встроенный тестовый пайплайн для объективной оценки качества поиска и ресурсоэффективности.

```bash
# Быстрый тест одного сервера
python lite/bench_pipeline.py --port 6005 --server DO_AME

# Полный отчёт по всем серверам
python lite/bench_full_report.py

# Расширенные метрики (качество + RAM + latency)
python lite/bench_metrics.py --only both
python lite/bench_metrics.py --json          # машиночитаемый формат
```

**Система метрик:**

| Категория | Метрика | Описание | Цель |
|-----------|---------|----------|------|
| Quality | **P@1** | Правильный ответ на 1-м месте | >70% |
| Quality | **P@3** | Правильный ответ в top-3 | >85% |
| Quality | **P@5** | Правильный ответ в top-5 | >90% |
| Quality | **MRR** | Mean Reciprocal Rank | >0.7 |
| Quality | **Score Separation** | Отношение score попаданий к промахам | >5x |
| Quality | **Confidence** | % запросов со score > 0.3 | >60% |
| Quality | **FP Rate** | Высокоскорящие неправильные ответы | <5% |
| Resource | **Container RAM** | Потребление памяти контейнером | <1500 MB |
| Resource | **Embedding DB** | Размер sqlite-vec на диске | — |
| Resource | **Avg Latency** | Среднее время ответа на запрос | <1000 ms |
| Resource | **P95 Latency** | 95-перцентиль времени ответа | <3000 ms |
| Combined | **Efficiency Score** | quality * (1 - ram_penalty), 0-100 | >60 |

**Масштабируемость:**
- Тест-сьюты определяются как Python-списки `(op, query, expected_names)`
- Добавление нового сервера — одна строка в `SUITES`
- `--json` вывод для CI/CD интеграции
- Ground truth расширяется на основе реальных результатов

---

## Архитектура

```
                  Memgraph (bolt://7687)
                        |
          +-------------+-------------+
          |                           |
     project_A :6001            project_B :6002
     (Python FastMCP, SSE)      (Python FastMCP, SSE)
          |                           |
   +------+------+            +------+------+
   | Graph Search |            | Graph Search |
   | (14 операций)|            | (14 операций)|
   +------+------+            +------+------+
   | Hybrid Search|            | Hybrid Search|
   | E5 + CE + BM25            | E5 + CE + BM25
   +------+------+            +------+------+
   | sqlite-vec   |            | sqlite-vec   |
   | embeddings.db|            | embeddings.db|
   +--------------+            +--------------+
```

**Компоненты:**

- **Memgraph** (C++) — графовая БД, Bolt-протокол, совместима с Neo4j-драйвером
- **MCP-сервисы** — Python 3.12 + FastMCP 3.2, SSE-транспорт
- **E5-base** (multilingual) — embedding модель 768 dim, prefix `query:` / `passage:`
- **Cross-encoder** — ONNX reranker для точности порядка результатов
- **sqlite-vec** + **FTS5** — векторный + полнотекстовый поиск на диске
- Все проекты используют один Memgraph, изолируются по `project_name`

---

## Быстрый старт

### 1. Подготовьте данные

Каждому проекту нужна директория с двумя поддиректориями:

```
ваш-проект/
  metadata/
    ОтчетПоКонфигурации.txt     # Конфигуратор -> Конфигурация -> Отчёт по конфигурации
  code/
    ConfigDumpInfo.xml            # GUID-маппинг (опционально)
    ОбщиеМодули/                  # BSL исходники
    Справочники/
    Документы/
    ...
```

> Экспорт отчёта: **Конфигуратор → Конфигурация → Отчёт по конфигурации** (формат `.txt`, все объекты).
> Экспорт исходников: **Конфигурация → Выгрузить конфигурацию в файлы**.

### 2. Создайте свой compose

```bash
cd lite/
cp docker-compose.example.yml docker-compose.yml
```

В новом `docker-compose.yml` подставьте свои пути:

```yaml
volumes:
  - /path/to/data/my_project:/app/data
```

И уникальное имя проекта:

```yaml
environment:
  - PROJECT_NAME=my_project
```

### 3. Запуск

```bash
docker compose build
docker compose up -d memgraph
docker compose up -d litecode-my_project
```

MCP-сервер **сразу** принимает запросы. Данные и embeddings грузятся в фоне — прогресс виден в `docker logs`.

### 4. Подключите к AI-ассистенту

**Claude Code:**

```bash
claude mcp add my_project --transport sse http://localhost:6001/sse
```

**Cursor / Windsurf / Cline:** SSE-эндпоинт `http://localhost:6001/sse`.

---

## MCP-инструменты

### `search_metadata` — структурный поиск

14 операций над графом + code search. Все принимают JSON через единый tool-вход.

```json
{"op": "browse", "name": "Контрагент"}
{"op": "object_structure", "name": "ДокументыПредприятия"}
{"op": "get_children", "name": "РеализацияТоваров", "child_type": "Attribute"}
{"op": "get_routines", "name": "ОтправитьЗапрос"}
{"op": "get_references", "name": "Контрагенты", "direction": "incoming"}
{"op": "find_routines_by_description", "text": "штрихкод"}
```

| Операция | Описание |
|----------|----------|
| `browse` | Категории, объекты, поиск по имени |
| `object_structure` | Полная карточка объекта |
| `get_children` | Реквизиты, ресурсы, измерения, табличные части, команды, макеты |
| `find_by_child` | Найти объекты по имени реквизита/ТЧ |
| `get_form` | Формы, элементы управления, события, привязки |
| `get_routines` | Процедуры/функции по имени, модулю, флагам |
| `get_routine_body` | Исходный код процедуры |
| `get_call_graph` | Кто вызывает / кого вызывает / дерево вызовов |
| `get_predefined` | Предопределённые элементы справочников |
| `get_access` | Права ролей |
| `get_references` | USED_IN, MOVEMENTS_IN |
| `get_subscriptions` | Подписки на события |
| `get_http_service` | HTTP-сервисы, URL-шаблоны |
| `resolve` | Разрешить qualified_name, GUID или префикс |
| `find_routines_by_description` | Поиск процедур по описанию (BSL doc-comments) |

### `search_by_embedding` — семантический поиск

Ищет по смыслу, когда не знаете точное имя.

```json
{"op": "search_routines", "text": "работа со штрихкодами и кодированием"}
{"op": "search_objects", "text": "справочник видов операций с документами"}
{"op": "search_all", "text": "архив документов"}
{"op": "search_metadata_by_description", "text": "документы предприятия"}
```

**Pipeline запроса:**

1. E5-base токенизация и embedding (768 dim, prefix `query:`)
2. sqlite-vec KNN top-20 по cosine + FTS5 BM25 top-20 по словам
3. Hybrid merge с адаптивными весами (85% embedding + 15% BM25, либо 50/50 если embedding слабый)
4. Cross-encoder reranking top-20 → top-7
5. Category boost + dynamic threshold

> **Tip:** описывайте ЧТО объект делает, а не его техническое имя.
> Хорошо: «справочник видов операций с документами».
> Плохо: «АМЕ_ВидыОпераций».

---

## Конфигурация

| Переменная | Описание | По умолчанию |
|------------|----------|:------------:|
| `PROJECT_NAME` | Уникальный идентификатор проекта | `default` |
| `MEMGRAPH_URI` | Bolt URI для Memgraph | `bolt://memgraph:7687` |
| `MCP_PORT` | Порт MCP-сервера в контейнере | `6001` |
| `FULL_METADATA_RELOAD` | Пересоздавать граф при старте | `false` |
| `LOAD_BSL_SIGNATURES` | Парсить .bsl файлы | `true` |
| `LOAD_FORMS_FROM_XML` | Парсить Form.xml | `true` |
| `LOAD_PREDEFINED_VALUES` | Парсить Predefined.xml | `true` |
| `LOAD_ROLE_RIGHTS` | Парсить Rights.xml | `true` |
| `ENABLE_EMBEDDING` | Включить семантический поиск | `false` |
| `EMBEDDING_MODEL_PATH` | Путь к ONNX модели embedding | `/app/models/e5-base` |
| `RERANKER_MODEL_PATH` | Путь к ONNX cross-encoder | `/app/models/cross-encoder` |
| `EMBEDDING_BATCH_SIZE` | Inner batch для ONNX-инференса | `64` |
| `EMBEDDING_STREAM_CHUNK` | Размер чанка streaming-индексации | `2000` |
| `EMBEDDING_QUERY_PREFIX` | E5-префикс для запросов | `query:` |
| `EMBEDDING_PASSAGE_PREFIX` | E5-префикс для документов | `passage:` |
| `SSE_PING_INTERVAL` | TCP keep-alive SSE-соединения, сек | `10` |
| `HEARTBEAT_LOG_INTERVAL` | Heartbeat в docker logs, сек | `30` |

---

## Модель графа

```
Project
  +-- Configuration
        +-- MetadataCategory
              +-- MetadataObject
                    |-- Attribute (с type_info)
                    |-- Resource
                    |-- Dimension
                    |-- TabularPart
                    |     +-- Attribute
                    |-- Form
                    |     |-- FormControl --BINDS_TO--> FormAttribute
                    |     +-- FormEvent
                    |-- EnumValue
                    |-- PredefinedItem
                    |-- Command, Layout
                    +-- Module
                          +-- Routine --CALLS--> Routine

MetadataObject --USED_IN--> MetadataObject        (типы реквизитов + BSL-код)
MetadataObject --MOVEMENTS_IN--> MetadataObject (документы -> регистры)
MetadataObject --GRANTS_ACCESS_TO--> MetadataObject (роли)
```

**`USED_IN`** строится из двух источников:

1. Типы реквизитов (`СправочникСсылка.Контрагенты` в metadata)
2. BSL-код (`Справочники.Контрагенты.НайтиПоКоду(...)` в исходниках)

**`MOVEMENTS_IN`** строится из паттернов `Движения.ИмяРегистра.Записать()` в модулях документов.

---

## Известные ограничения

- **Кириллица в `toLower()`** — Memgraph не работает с кириллицей в `toLower()`; поиск использует множественные варианты регистра из Python.
- **Embedding пиковый RAM** — для гигантских баз (~600k+ рутин) индексация теперь идёт **streaming-режимом** с peak ~2.5 ГБ. Для средних баз (~8k объектов) ~1 ГБ.
- **Embedding модели не в образе** — ONNX-модели (E5-base, cross-encoder) скачиваются отдельно в `lite/mcp-service/models/`. Без них `ENABLE_EMBEDDING=true` упадёт при старте.
- **Скорость embedding'а** — на CPU (без GPU) 600k рутин индексируются ~10–18 часов. Streaming делает это безопасным (resumable, без OOM), но не быстрым. Для регулярных пересборок имеет смысл переходить на GPU или e5-small.

---

## YouTube — про 1С, AI и автоматизацию

<p align="center">
  <a href="https://www.youtube.com/@svhovvv">
    <img src="https://img.shields.io/badge/YouTube-@svhovvv-FF0000?style=for-the-badge&logo=youtube&logoColor=white" alt="YouTube" />
  </a>
</p>

На канале **[@svhovvv](https://www.youtube.com/@svhovvv)** — практика построения AI-инструментов вокруг 1С:Предприятие, разборы реальных конфигураций, MCP-серверы, Claude Code, автоматизация рутины разработчика, и закулисье этого проекта. Если зашло — **подписывайтесь**, это лучшая благодарность автору.

---

## Поддержать проект

Если 1C Litecode MCP сэкономил вам часы разбирательства в чужих конфигурациях — можно поблагодарить рублём.

| Сбербанк | `2202 2054 0027 9540` |
|:---------|:----------------------|
| Получатель | Сухов Андрей Евгеньевич |

И не забудьте про **[звезду на GitHub](https://github.com/svhov/1c-litecode-mcp)** и **[подписку на YouTube](https://www.youtube.com/@svhovvv)** — это бесплатно и сильно помогает проекту находить аудиторию.

---

## Авторы

<table>
  <tr>
    <td align="center">
      <a href="https://github.com/svhov">
        <img src="https://github.com/svhov.png" width="80" style="border-radius:50%" alt="svhov"/><br/>
        <sub><b>Сухов Андрей</b></sub>
      </a><br/>
      <sub>Автор проекта</sub>
    </td>
    <td align="center">
      <a href="https://github.com/anthropics">
        <img src="https://github.com/anthropics.png" width="80" style="border-radius:50%" alt="Claude"/><br/>
        <sub><b>Claude (Anthropic)</b></sub>
      </a><br/>
      <sub>AI co-author</sub>
    </td>
    <td align="center">
      <a href="https://github.com/jlowin">
        <img src="https://github.com/jlowin.png" width="80" style="border-radius:50%" alt="jlowin"/><br/>
        <sub><b>Jeremiah Lowin</b></sub>
      </a><br/>
      <sub>Автор <a href="https://github.com/jlowin/fastmcp">FastMCP</a></sub>
    </td>
  </tr>
</table>

---

## Лицензия

[MIT](LICENSE) — Copyright (c) 2026 Сухов Андрей Евгеньевич.

Используйте, форкайте, дописывайте, продавайте — без ограничений. Только не убирайте упоминание автора в коде.

---

<p align="center">
  <a href="https://www.youtube.com/@svhovvv">
    <img src="https://img.shields.io/badge/YouTube-@svhovvv-FF0000?style=flat-square&logo=youtube&logoColor=white" alt="YouTube" />
  </a>
  &nbsp;&nbsp;
  <a href="https://github.com/svhov/1c-litecode-mcp">
    <img src="https://img.shields.io/badge/GitHub-Поставить_★-181717?style=flat-square&logo=github&logoColor=white" alt="GitHub" />
  </a>
</p>

<p align="center">
  <sub>Сделано в России для разработчиков 1С — теми, кто устал искать «где же это объявлено» руками.</sub>
</p>
