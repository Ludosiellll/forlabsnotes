"""Loads parsed data into Memgraph."""

import logging
import os

from app.config import (
    PROJECT_NAME, CODE_DIR, METADATA_DIR,
    FULL_METADATA_RELOAD, LOAD_BSL_SIGNATURES,
    LOAD_FORMS_FROM_XML, LOAD_PREDEFINED_VALUES, LOAD_ROLE_RIGHTS,
    ENABLE_EMBEDDING, EMBEDDING_MODEL_PATH, EMBEDDING_DB_PATH,
    EMBEDDING_BATCH_SIZE, EMBEDDING_STREAM_CHUNK,
    EMBEDDING_QUERY_PREFIX, EMBEDDING_PASSAGE_PREFIX,
    RERANKER_MODEL_PATH,
)
from app.db.connection import run_query, run_write
from app.db.indexes import ensure_indexes
from app.parsers.metadata_report import parse_metadata_report
from app.parsers.bsl_parser import scan_bsl_files
from app.parsers.form_parser import scan_forms
from app.parsers.predefined_parser import scan_predefined
from app.parsers.roles_parser import scan_roles
from app.parsers.config_dump import parse_config_dump

log = logging.getLogger(__name__)

CHUNK_SIZE = 500

# Module-level subsystem membership map: object_name -> [subsystem_display_name]
# Built from "Состав" property of subsystem objects in the metadata report.
_subsystem_map: dict[str, list[str]] = {}


def _chunk(lst, size):
    for i in range(0, len(lst), size):
        yield lst[i:i + size]


def _project_data_exists() -> bool:
    """Check if project data already loaded."""
    result = run_query(
        "MATCH (p:Project {name: $name}) RETURN p.name AS name",
        {"name": PROJECT_NAME},
    )
    if not result:
        return False
    obj_count = run_query(
        "MATCH (n:MetadataObject {project_name: $name}) RETURN count(n) AS cnt",
        {"name": PROJECT_NAME},
    )
    return obj_count and obj_count[0].get("cnt", 0) > 0


def _clear_project():
    """Remove all data for this project."""
    log.info("Clearing project data: %s", PROJECT_NAME)
    run_write(
        "MATCH (n) WHERE n.project_name = $name DETACH DELETE n",
        {"name": PROJECT_NAME},
    )
    run_write(
        "MATCH (p:Project {name: $name}) DETACH DELETE p",
        {"name": PROJECT_NAME},
    )
    log.info("Project data cleared")


def _load_metadata(config):
    """Load parsed metadata into graph."""
    log.info("Loading metadata: %s (%d objects)", config.config_name, config.object_count)

    # Create Project node
    run_write(
        "MERGE (p:Project {name: $name})",
        {"name": PROJECT_NAME},
    )

    # Create Configuration node
    run_write("""
        MERGE (c:Configuration {qualified_name: $qn})
        SET c.name = $name, c.project_name = $project
        WITH c
        MATCH (p:Project {name: $project})
        MERGE (p)-[:HAS_CONFIGURATION]->(c)
    """, {
        "qn": f"{PROJECT_NAME}/{config.config_name}",
        "name": config.config_name,
        "project": PROJECT_NAME,
    })

    # Set config properties
    for key, val in config.config_props.items():
        safe_key = key.replace(" ", "_").replace(".", "_")
        try:
            run_write(f"""
                MATCH (c:Configuration {{qualified_name: $qn}})
                SET c.`{safe_key}` = $val
            """, {"qn": f"{PROJECT_NAME}/{config.config_name}", "val": val})
        except Exception:
            pass

    # Create categories
    for cat in config.categories:
        cat_qn = f"{PROJECT_NAME}/{config.config_name}/{cat['name']}"
        run_write("""
            MERGE (mc:MetadataCategory {qualified_name: $qn})
            SET mc.name = $name, mc.project_name = $project, mc.config_name = $config
            WITH mc
            MATCH (c:Configuration {qualified_name: $conf_qn})
            MERGE (c)-[:HAS_CATEGORY]->(mc)
        """, {
            "qn": cat_qn,
            "name": cat["name"],
            "project": PROJECT_NAME,
            "config": config.config_name,
            "conf_qn": f"{PROJECT_NAME}/{config.config_name}",
        })

    # Create objects in chunks
    for chunk in _chunk(config.objects, CHUNK_SIZE):
        rows = []
        for obj in chunk:
            qn = f"{PROJECT_NAME}/{config.config_name}/{obj['category']}/{obj['name']}"
            cat_qn = f"{PROJECT_NAME}/{config.config_name}/{obj['category']}"
            row = {
                "qn": qn,
                "name": obj["name"],
                "category": obj["category"],
                "category_en": obj["category_en"],
                "project": PROJECT_NAME,
                "config": config.config_name,
                "synonym": obj["properties"].get("Синоним", ""),
                "comment": obj["properties"].get("Комментарий", ""),
                "cat_qn": cat_qn,
            }
            rows.append(row)

        run_write("""
            UNWIND $rows AS r
            MERGE (mo:MetadataObject {qualified_name: r.qn})
            SET mo.name = r.name,
                mo.category_name = r.category,
                mo.category_name_en = r.category_en,
                mo.project_name = r.project,
                mo.config_name = r.config,
                mo.Synonym = r.synonym,
                mo.Comment = r.comment
            WITH mo, r
            MATCH (mc:MetadataCategory {qualified_name: r.cat_qn})
            MERGE (mc)-[:CONTAINS_OBJECT]->(mo)
        """, {"rows": rows})

    log.info("Loaded %d objects", config.object_count)

    # Load child nodes (attributes, resources, dimensions, etc.)
    _load_children(config)

    # Build subsystem membership map from "Состав" property
    _build_subsystem_map(config)


def _build_subsystem_map(config):
    """Build object_name -> [subsystem_name] map from subsystem Состав property.

    The metadata report stores subsystem composition as:
        Подсистемы.УправлениеЗакупками
            Состав:
                "Документы.ЗаказПоставщику"
                "Справочники.Контрагенты"
    """
    global _subsystem_map
    _subsystem_map = {}
    total = 0

    for obj in config.objects:
        if obj["category"] != "Подсистемы":
            continue
        members = obj["properties"].get("Состав", [])
        if not isinstance(members, list) or not members:
            continue

        # Use synonym as display name, fallback to name
        subsystem_label = obj["properties"].get("Синоним", "") or obj["name"]

        for member in members:
            # member format: "Документы.ЗаказПоставщику" or "Справочники.Контрагенты"
            parts = member.split(".")
            if len(parts) >= 2:
                obj_name = parts[1]
                lst = _subsystem_map.setdefault(obj_name, [])
                if subsystem_label not in lst:
                    lst.append(subsystem_label)
                    total += 1

    if total:
        log.info("Built subsystem map: %d object-subsystem links from %d subsystems",
                 total, sum(1 for o in config.objects if o["category"] == "Подсистемы"))


import re as _re

_VALID_CYPHER_LABEL = _re.compile(r"^[A-Za-z_]\w*$")


def _load_children(config):
    """Load child nodes (attributes, tabular parts, etc.)."""
    for obj in config.objects:
        obj_qn = f"{PROJECT_NAME}/{config.config_name}/{obj['category']}/{obj['name']}"
        children = obj.get("children", {})

        for child_type, child_list in children.items():
            if not _VALID_CYPHER_LABEL.match(child_type):
                log.warning("Skipping invalid child_type: %r", child_type)
                continue
            label = child_type  # Attribute, Resource, Dimension, etc.
            rel = _child_rel(child_type)

            for child in child_list:
                child_qn = f"{obj_qn}/{child_type}/{child['name']}"
                props = {"qn": child_qn, "name": child["name"], "obj_qn": obj_qn}

                # Add type info if present
                type_val = child.get("properties", {}).get("Тип", "")
                synonym = child.get("properties", {}).get("Синоним", "")

                run_write(f"""
                    MERGE (ch:{label} {{qualified_name: $qn}})
                    SET ch.name = $name, ch.type_info = $type_val, ch.Synonym = $synonym
                    WITH ch
                    MATCH (mo:MetadataObject {{qualified_name: $obj_qn}})
                    MERGE (mo)-[:{rel}]->(ch)
                """, {**props, "type_val": type_val, "synonym": synonym})

                # TabularPart children (attributes of tabular section)
                if child_type == "TabularPart":
                    for tab_child in child.get("children", []):
                        tab_attr_qn = f"{child_qn}/Attribute/{tab_child['name']}"
                        tab_type = tab_child.get("properties", {}).get("Тип", "")
                        run_write("""
                            MERGE (ta:Attribute {qualified_name: $qn})
                            SET ta.name = $name, ta.type_info = $type_val
                            WITH ta
                            MATCH (tp:TabularPart {qualified_name: $tp_qn})
                            MERGE (tp)-[:HAS_ATTRIBUTE]->(ta)
                        """, {
                            "qn": tab_attr_qn,
                            "name": tab_child["name"],
                            "type_val": tab_type,
                            "tp_qn": child_qn,
                        })


def _child_rel(child_type: str) -> str:
    return {
        "Attribute": "HAS_ATTRIBUTE",
        "Resource": "HAS_RESOURCE",
        "Dimension": "HAS_DIMENSION",
        "Characteristic": "HAS_CHARACTERISTIC",
        "TabularPart": "HAS_TABULAR_PART",
        "EnumValue": "HAS_ENUM_VALUE",
        "Form": "HAS_FORM",
        "Layout": "HAS_LAYOUT",
        "Command": "HAS_COMMAND",
        "AccountingFlag": "HAS_ACCOUNTING_FLAG",
        "DimensionAccountingFlag": "HAS_DIM_ACCOUNTING_FLAG",
        "JournalGraph": "HAS_JOURNAL_GRAPH",
        "UrlTemplate": "HAS_URL_TEMPLATE",
        "UrlMethod": "HAS_URL_METHOD",
    }.get(child_type, "HAS_CHILD")


def _load_routines(routines: list[dict]):
    """Load BSL routines and modules into graph."""
    log.info("Loading %d routines...", len(routines))

    # Group by owner to create Module nodes
    owners = {}
    for r in routines:
        owners.setdefault(r["owner_qn"], []).append(r)

    for owner_qn, owner_routines in owners.items():
        # Create Module node
        parts = owner_qn.split("/")
        module_name = parts[-1] if len(parts) > 2 else owner_qn

        # Determine module type from file path
        first_routine = owner_routines[0]
        fp = first_routine.get("file_path", "")
        if "ObjectModule" in fp or "/Ext/ObjectModule.bsl" in fp:
            module_type = "ObjectModule"
        elif "ManagerModule" in fp or "/Ext/ManagerModule.bsl" in fp:
            module_type = "ManagerModule"
        elif "CommonModules" in fp:
            module_type = "CommonModule"
        elif "Form" in fp:
            module_type = "FormModule"
        else:
            module_type = "Module"

        module_id = f"module:{owner_qn}"
        run_write("""
            MERGE (m:Module {id: $id})
            SET m.name = $name, m.module_type = $mtype,
                m.owner_qn = $owner_qn,
                m.project_name = $project, m.config_name = $config,
                m.path = $path
        """, {
            "id": module_id,
            "name": module_name,
            "mtype": module_type,
            "owner_qn": owner_qn,
            "project": first_routine["project_name"],
            "config": first_routine["config_name"],
            "path": fp,
        })

        # Link module to owner MetadataObject if possible
        # owner_qn format: project/config/Category/ObjectName[/Form/FormName]
        if len(parts) >= 4:
            obj_qn = "/".join(parts[:4])
            run_write("""
                MATCH (mo:MetadataObject {qualified_name: $obj_qn})
                MATCH (m:Module {id: $mid})
                MERGE (mo)-[:HAS_MODULE]->(m)
            """, {"obj_qn": obj_qn, "mid": module_id})

    # Load routines in chunks
    for chunk in _chunk(routines, CHUNK_SIZE):
        rows = [{
            "id": r["id"],
            "name": r["name"],
            "routine_type": r["routine_type"],
            "directive": r["directive"],
            "export": r["export"],
            "is_ssl_api": r["is_ssl_api"],
            "signature": r["signature"],
            "params_text": r["params_text"],
            "param_names": ", ".join(r["param_names"]) if isinstance(r["param_names"], list) else r["param_names"],
            "body": r["body"],
            "line": r["line"],
            "file_path": r["file_path"],
            "area_path": r["area_path"],
            "owner_qn": r["owner_qn"],
            "project_name": r["project_name"],
            "config_name": r["config_name"],
            "doc_description": r.get("doc_description", ""),
            "doc_params_text": r.get("doc_params_text", ""),
            "doc_return_text": r.get("doc_return_text", ""),
            "module_id": f"module:{r['owner_qn']}",
        } for r in chunk]

        run_write("""
            UNWIND $rows AS r
            MERGE (rt:Routine {id: r.id})
            SET rt.name = r.name,
                rt.routine_type = r.routine_type,
                rt.directive = r.directive,
                rt.export = r.export,
                rt.is_ssl_api = r.is_ssl_api,
                rt.signature = r.signature,
                rt.params_text = r.params_text,
                rt.param_names = r.param_names,
                rt.body = r.body,
                rt.line = r.line,
                rt.file_path = r.file_path,
                rt.area_path = r.area_path,
                rt.owner_qn = r.owner_qn,
                rt.project_name = r.project_name,
                rt.config_name = r.config_name,
                rt.doc_description = r.doc_description,
                rt.doc_params_text = r.doc_params_text,
                rt.doc_return_text = r.doc_return_text
            WITH rt, r
            MATCH (m:Module {id: r.module_id})
            MERGE (m)-[:DECLARES]->(rt)
        """, {"rows": rows})

    # Build CALLS relationships
    _build_calls(routines)
    log.info("Routines loaded")


def _build_calls(routines: list[dict]):
    """Build CALLS edges between routines."""
    # Build name -> id index for this project
    name_to_id = {}
    for r in routines:
        name_to_id.setdefault(r["name"], []).append(r["id"])

    call_pairs = []
    for r in routines:
        for call_name in r.get("calls", []):
            targets = name_to_id.get(call_name, [])
            for target_id in targets:
                if target_id != r["id"]:
                    call_pairs.append({"from_id": r["id"], "to_id": target_id})

    if call_pairs:
        for chunk in _chunk(call_pairs, CHUNK_SIZE):
            run_write("""
                UNWIND $pairs AS p
                MATCH (a:Routine {id: p.from_id})
                MATCH (b:Routine {id: p.to_id})
                MERGE (a)-[:CALLS]->(b)
            """, {"pairs": chunk})
        log.info("Created %d CALLS edges", len(call_pairs))


def _load_forms(forms: list[dict]):
    """Load form controls, attributes, events into graph."""
    log.info("Loading %d forms...", len(forms))
    for form_data in forms:
        owner_qn = form_data["owner_qn"]

        for ctrl in form_data.get("controls", []):
            run_write("""
                MERGE (fc:FormControl {qualified_name: $qn})
                SET fc.name = $name, fc.control_type = $ctype, fc.data_path = $dp
            """, {
                "qn": ctrl["qualified_name"],
                "name": ctrl["name"],
                "ctype": ctrl["type"],
                "dp": ctrl["data_path"],
            })
            # Bind to data path if present
            if ctrl["data_path"]:
                run_write("""
                    MATCH (fc:FormControl {qualified_name: $ctrl_qn})
                    MATCH (fa:FormAttribute {qualified_name: $fa_qn})
                    MERGE (fc)-[:BINDS_TO]->(fa)
                """, {
                    "ctrl_qn": ctrl["qualified_name"],
                    "fa_qn": f"{owner_qn}/Attribute/{ctrl['data_path']}",
                })

        for attr in form_data.get("attributes", []):
            run_write("""
                MERGE (fa:FormAttribute {qualified_name: $qn})
                SET fa.name = $name
            """, {"qn": attr["qualified_name"], "name": attr["name"]})

        for event in form_data.get("events", []):
            run_write("""
                MERGE (fe:FormEvent {qualified_name: $qn})
                SET fe.name = $name, fe.handler = $handler
            """, {
                "qn": event["qualified_name"],
                "name": event["name"],
                "handler": event["handler"],
            })

    log.info("Forms loaded")


def _load_predefined(items: list[dict]):
    """Load predefined items into graph."""
    log.info("Loading %d predefined items...", len(items))
    for chunk in _chunk(items, CHUNK_SIZE):
        rows = [{
            "qn": it["qualified_name"],
            "name": it["name"],
            "description": it["description"],
            "is_folder": it["is_folder"],
        } for it in chunk]

        run_write("""
            UNWIND $rows AS r
            MERGE (pi:PredefinedItem {qualified_name: r.qn})
            SET pi.name = r.name, pi.description = r.description, pi.is_folder = r.is_folder
        """, {"rows": rows})

        # Link to owner by extracting object name from file path
        for it in chunk:
            # owner_qn from file: project/config/Catalogs/ObjectName
            # Extract object name (last part before /Predefined/)
            parts = it["owner_qn"].split("/")
            obj_name = parts[-1] if parts else ""
            if obj_name:
                run_write("""
                    MATCH (mo:MetadataObject)
                    WHERE mo.project_name = $project AND mo.name = $obj_name
                    MATCH (pi:PredefinedItem {qualified_name: $pi_qn})
                    MERGE (mo)-[:HAS_PREDEFINED]->(pi)
                """, {
                    "project": PROJECT_NAME,
                    "obj_name": obj_name,
                    "pi_qn": it["qualified_name"],
                })

    log.info("Predefined items loaded")


def _load_roles(grants: list[dict], config_name: str):
    """Load role access rights into graph."""
    log.info("Loading %d role grants...", len(grants))
    for grant in grants:
        # Ensure Role node exists as MetadataObject
        role_qn = f"{PROJECT_NAME}/{config_name}/Роли/{grant['role_name']}"

        # Target uses dot notation (e.g. Catalog.SomeName) -> find MetadataObject
        rights_str = ",".join(grant["rights"].keys())
        run_write("""
            MATCH (role:MetadataObject {qualified_name: $role_qn})
            MATCH (target:MetadataObject)
            WHERE target.name = $target_name AND target.project_name = $project
            MERGE (role)-[r:GRANTS_ACCESS_TO]->(target)
            SET r.rights = $rights
        """, {
            "role_qn": role_qn,
            "target_name": grant["target_name"].split(".")[-1],
            "project": PROJECT_NAME,
            "rights": rights_str,
        })

    log.info("Role grants loaded")


def _load_guid_map(guid_map: dict[str, str]):
    """Store GUID mapping on existing nodes (batched for performance)."""
    log.info("Mapping %d GUIDs...", len(guid_map))
    BATCH_SIZE = 500
    batch = []
    for name, uid in guid_map.items():
        parts = name.split(".")
        obj_name = parts[1] if len(parts) >= 2 else parts[0]
        batch.append({"name": obj_name, "uid": uid})
        if len(batch) >= BATCH_SIZE:
            run_write("""
                UNWIND $batch AS item
                MATCH (n {name: item.name})
                WHERE n.project_name = $project
                SET n.guid = item.uid
            """, {"batch": batch, "project": PROJECT_NAME})
            batch = []
    if batch:
        run_write("""
            UNWIND $batch AS item
            MATCH (n {name: item.name})
            WHERE n.project_name = $project
            SET n.guid = item.uid
        """, {"batch": batch, "project": PROJECT_NAME})
    log.info("GUID mapping complete")


def _build_used_in():
    """Build USED_IN edges from type references in attributes, dimensions, resources.

    Parses type_info like 'СправочникСсылка.Контрагенты' to create
    USED_IN edges from the owning MetadataObject to the referenced one.
    """
    import re

    # Type prefixes that indicate references to other metadata objects
    REF_PATTERN = re.compile(
        r"("
        # Catalog/Document/Enum references
        r"СправочникСсылка|ДокументСсылка|ПеречислениеСсылка|"
        # Plans
        r"ПланВидовХарактеристикСсылка|ПланСчетовСсылка|ПланВидовРасчетаСсылка|"
        # Business processes
        r"БизнесПроцессСсылка|ЗадачаСсылка|"
        # Register record sets
        r"РегистрСведенийНаборЗаписей|РегистрНакопленияНаборЗаписей|"
        r"РегистрБухгалтерииНаборЗаписей|РегистрРасчетаНаборЗаписей|"
        # Register record types
        r"РегистрСведенийЗапись|РегистрНакопленияЗапись|"
        # Register keys and managers
        r"РегистрСведенийКлючЗаписи|"
        r"РегистрСведенийМенеджер|РегистрНакопленияМенеджер|"
        # English equivalents
        r"CatalogRef|DocumentRef|EnumRef|"
        r"ChartOfCharacteristicTypesRef|ChartOfAccountsRef|ChartOfCalculationTypesRef|"
        r"InformationRegisterRecordSet|AccumulationRegisterRecordSet|"
        r"AccountingRegisterRecordSet|CalculationRegisterRecordSet"
        r")\."
        r"(\w+)"
    )

    # Get all nodes with type_info that contain references
    rows = run_query("""
        MATCH (owner:MetadataObject)-[]->(child)
        WHERE child.type_info IS NOT NULL
          AND (child.type_info CONTAINS 'Ссылка'
               OR child.type_info CONTAINS 'НаборЗаписей'
               OR child.type_info CONTAINS 'Запись'
               OR child.type_info CONTAINS 'Менеджер'
               OR child.type_info CONTAINS 'Ref'
               OR child.type_info CONTAINS 'RecordSet')
        RETURN DISTINCT owner.qualified_name AS owner_qn, child.type_info AS type_info
    """)

    pairs = set()
    for row in rows:
        owner_qn = row["owner_qn"]
        type_info = row["type_info"]
        # type_info can have multiple types comma-separated
        for match in REF_PATTERN.finditer(type_info):
            ref_name = match.group(2)
            pairs.add((owner_qn, ref_name))

    if not pairs:
        log.info("No USED_IN references found in type_info")
        return

    log.info("Building %d USED_IN edges from type references...", len(pairs))
    pair_list = [{"owner_qn": p[0], "ref_name": p[1]} for p in pairs]

    for chunk in _chunk(pair_list, CHUNK_SIZE):
        run_write("""
            UNWIND $pairs AS p
            MATCH (owner:MetadataObject {qualified_name: p.owner_qn})
            MATCH (target:MetadataObject {name: p.ref_name})
            MERGE (owner)-[:USED_IN]->(target)
        """, {"pairs": chunk})

    log.info("USED_IN edges created")


# Map BSL plural category names -> metadata category names
_BSL_CATEGORY_TO_META = {
    "Справочники": "Справочники", "Документы": "Документы",
    "Перечисления": "Перечисления",
    "РегистрыСведений": "РегистрыСведений", "РегистрыНакопления": "РегистрыНакопления",
    "РегистрыБухгалтерии": "РегистрыБухгалтерии", "РегистрыРасчета": "РегистрыРасчета",
    "ПланыВидовХарактеристик": "ПланыВидовХарактеристик",
    "ПланыСчетов": "ПланыСчетов", "ПланыВидовРасчета": "ПланыВидовРасчета",
    "БизнесПроцессы": "БизнесПроцессы", "Задачи": "Задачи",
    "Константы": "Константы", "Обработки": "Обработки", "Отчеты": "Отчеты",
    "Catalogs": "Справочники", "Documents": "Документы", "Enums": "Перечисления",
    "InformationRegisters": "РегистрыСведений", "AccumulationRegisters": "РегистрыНакопления",
    "AccountingRegisters": "РегистрыБухгалтерии", "CalculationRegisters": "РегистрыРасчета",
    "ChartsOfCharacteristicTypes": "ПланыВидовХарактеристик",
    "ChartsOfAccounts": "ПланыСчетов", "ChartsOfCalculationTypes": "ПланыВидовРасчета",
    "BusinessProcesses": "БизнесПроцессы", "Tasks": "Задачи",
    "Constants": "Константы", "DataProcessors": "Обработки", "Reports": "Отчеты",
}


def _build_code_used_in(routines: list[dict]):
    """Build USED_IN edges from BSL code metadata references."""
    pairs = set()
    for r in routines:
        owner_parts = r["owner_qn"].split("/")
        if len(owner_parts) < 4:
            continue
        owner_obj_qn = "/".join(owner_parts[:4])

        for category_bsl, obj_name in r.get("metadata_refs", []):
            meta_cat = _BSL_CATEGORY_TO_META.get(category_bsl)
            if meta_cat:
                pairs.add((owner_obj_qn, meta_cat, obj_name))

    if not pairs:
        return

    log.info("Building %d code-based USED_IN edges...", len(pairs))
    pair_list = [{"owner_qn": p[0], "cat": p[1], "ref_name": p[2]} for p in pairs]

    for chunk in _chunk(pair_list, CHUNK_SIZE):
        run_write("""
            UNWIND $pairs AS p
            MATCH (owner:MetadataObject {qualified_name: p.owner_qn})
            MATCH (target:MetadataObject {name: p.ref_name, category_name: p.cat})
            WHERE target.project_name = $project
            MERGE (owner)-[:USED_IN {source: 'code'}]->(target)
        """, {"pairs": chunk, "project": PROJECT_NAME})

    log.info("Code-based USED_IN edges created")


_RE_MOVEMENT = _re.compile(
    r"\bДвижения\.(\w+)\s*\.\s*(Записать|Добавить|Записывать|Очистить|Write|Add|Clear)\b",
    _re.IGNORECASE,
)


def _build_movements(routines: list[dict]):
    """Build MOVEMENTS_IN edges from Document -> Register patterns in BSL code."""
    pairs = set()
    for r in routines:
        owner_parts = r["owner_qn"].split("/")
        if len(owner_parts) < 4:
            continue
        # Only process document modules
        if owner_parts[2] not in ("Documents", "Документы"):
            continue

        owner_obj_qn = "/".join(owner_parts[:4])
        body = r.get("body", "")
        for m in _RE_MOVEMENT.finditer(body):
            register_name = m.group(1)
            pairs.add((owner_obj_qn, register_name))

    if not pairs:
        log.info("No MOVEMENTS_IN references found in BSL code")
        return

    log.info("Building %d MOVEMENTS_IN edges...", len(pairs))
    pair_list = [{"doc_qn": p[0], "reg_name": p[1]} for p in pairs]

    for chunk in _chunk(pair_list, CHUNK_SIZE):
        run_write("""
            UNWIND $pairs AS p
            MATCH (doc:MetadataObject {qualified_name: p.doc_qn})
            MATCH (reg:MetadataObject {name: p.reg_name})
            WHERE reg.project_name = $project
              AND reg.category_name IN [
                  'РегистрыСведений', 'РегистрыНакопления',
                  'РегистрыБухгалтерии', 'РегистрыРасчета']
            MERGE (doc)-[:MOVEMENTS_IN]->(reg)
        """, {"pairs": chunk, "project": PROJECT_NAME})

    log.info("MOVEMENTS_IN edges created")


def _split_camel_case(name: str) -> str:
    """Split CamelCase/underscore name into words for embedding.

    АМЕ_ВидыОпераций → АМЕ Виды Операций
    ДокументыПредприятия → Документы Предприятия
    """
    # Replace underscores with spaces
    s = name.replace("_", " ")
    # Insert space before uppercase letters that follow lowercase
    result = []
    for i, ch in enumerate(s):
        if i > 0 and ch.isupper() and s[i - 1].islower():
            result.append(" ")
        result.append(ch)
    return "".join(result)


_MODULE_TYPE_RU = {
    "ObjectModule": "МодульОбъекта",
    "ManagerModule": "МодульМенеджера",
    "CommonModule": "ОбщийМодуль",
    "FormModule": "МодульФормы",
    "Module": "Модуль",
}

# Event handler name patterns for automatic event_name detection
_EVENT_NAMES = {
    "ПередЗаписью": "ПередЗаписью",
    "ПриЗаписи": "ПриЗаписи",
    "ПослеЗаписи": "ПослеЗаписи",
    "ПередУдалением": "ПередУдалением",
    "ОбработкаПроведения": "ОбработкаПроведения",
    "ОбработкаУдаленияПроведения": "ОбработкаУдаленияПроведения",
    "ПередПроведением": "ПередПроведением",
    "ПриКопировании": "ПриКопировании",
    "ПриСозданииНаСервере": "ПриСозданииНаСервере",
    "ПриОткрытии": "ПриОткрытии",
    "ПриЗакрытии": "ПриЗакрытии",
    "ПриИзменении": "ПриИзменении",
    "ОбработкаЗаполнения": "ОбработкаЗаполнения",
    "ОбработкаПолученияФормы": "ОбработкаПолученияФормы",
    "ПриЧтенииНаСервере": "ПриЧтенииНаСервере",
    "ПриПолученииДанныхНаСервере": "ПриПолученииДанныхНаСервере",
    "BeforeWrite": "BeforeWrite",
    "OnWrite": "OnWrite",
    "AfterWrite": "AfterWrite",
    "Posting": "Posting",
    "UndoPosting": "UndoPosting",
    "Filling": "Filling",
    "OnCreateAtServer": "OnCreateAtServer",
    "OnOpen": "OnOpen",
    "OnReadAtServer": "OnReadAtServer",
}


def _detect_event_name(routine_name: str) -> str:
    """Detect if routine is an event handler by name pattern."""
    for pattern, event in _EVENT_NAMES.items():
        if routine_name == pattern or routine_name.endswith(pattern):
            return event
    return ""


def _build_routine_text(r) -> str:
    """Compose enriched embedding text for a routine row.

    Format follows update_1.txt spec: owner context, signature, directive,
    region, description, param types, return type, event name, called objects.
    """
    parts = []
    owner_qn = r.get("owner_qn", "")
    owner = owner_qn.split("/")

    # 1. Owner context: category + object name
    if len(owner) >= 4:
        owner_cat = owner[2]
        owner_name = _split_camel_case(owner[3])
        parts.append(f"Модуль: {owner_cat}.{owner_name}")

    # 2. Module type
    module_type = r.get("module_type", "")
    if module_type:
        mt_ru = _MODULE_TYPE_RU.get(module_type, module_type)
        parts.append(f"Тип модуля: {mt_ru}")

    # 3. Signature line
    rtype = r.get("routine_type", "Procedure")
    prefix = "Функция" if rtype == "Function" else "Процедура"
    name = r.get("name", "")
    params = r.get("params_text", "")
    export_flag = " Экспорт" if r.get("export") else ""
    parts.append(f"{prefix} {name}({params}){export_flag}")

    # 4. Directive
    directive = r.get("directive", "")
    if directive:
        parts.append(f"Контекст: {directive}")

    # 5. Region / area_path
    area = r.get("area_path", "")
    if area:
        parts.append(f"Область: {area}")

    # 6. Description
    if r.get("doc_description"):
        parts.append(f"Описание: {r['doc_description']}")

    # 7. Event handler detection
    event = _detect_event_name(name)
    if event:
        parts.append(f"Событие: {event}")

    # 8. Parameter types (from documentation)
    doc_params = r.get("doc_params_text", "")
    if doc_params:
        parts.append(f"Параметры: {doc_params}")

    # 9. Return type (from documentation)
    doc_return = r.get("doc_return_text", "")
    if doc_return:
        parts.append(f"Возвращает: {doc_return}")

    # 10. Called objects (top 5, from pre-fetched map)
    called = r.get("_called_objects", [])
    if called:
        parts.append("Работает с: " + ", ".join(called[:5]))

    return "\n".join(parts)


def _adaptive_inner_batch(texts: list[str]) -> int:
    """Reduce inner batch_size when texts are long, to bound peak memory in ONNX."""
    if not texts:
        return EMBEDDING_BATCH_SIZE
    avg = sum(len(t) for t in texts) / len(texts)
    if avg < 800:
        return EMBEDDING_BATCH_SIZE
    if avg < 2000:
        return max(16, EMBEDDING_BATCH_SIZE // 2)
    return max(8, EMBEDDING_BATCH_SIZE // 4)


def _build_embeddings():
    """Generate embeddings for routines and metadata objects.

    Streaming pipeline: reads rows from Memgraph, embeds in chunks of
    EMBEDDING_STREAM_CHUNK, writes each chunk to sqlite-vec under one
    transaction, then frees buffers. Bounded RAM regardless of total count;
    crash-resilient because each committed chunk is durable on restart
    (resume happens automatically via text_hash skip).
    """
    from app.services.embedding import init, get_embedder, get_store, text_hash

    init(EMBEDDING_MODEL_PATH, EMBEDDING_DB_PATH,
         reranker_path=RERANKER_MODEL_PATH,
         query_prefix=EMBEDDING_QUERY_PREFIX,
         passage_prefix=EMBEDDING_PASSAGE_PREFIX)
    embedder = get_embedder()
    store = get_store()
    if embedder is None or store is None:
        log.warning("Embedding service not available, skipping")
        return

    # Fast path: if vector store counts match Memgraph, skip heavy embedding loop.
    # This avoids querying 92K rows just to check hashes on every restart.
    if not FULL_METADATA_RELOAD:
        routine_count_graph = run_query(
            "MATCH (r:Routine {project_name: $p}) RETURN count(r) AS cnt",
            {"p": PROJECT_NAME})
        obj_count_graph = run_query(
            "MATCH (mo:MetadataObject {project_name: $p}) RETURN count(mo) AS cnt",
            {"p": PROJECT_NAME})
        r_cnt = routine_count_graph[0]["cnt"] if routine_count_graph else 0
        o_cnt = obj_count_graph[0]["cnt"] if obj_count_graph else 0
        r_vec = store.count("routines")
        o_vec = store.count("objects")

        if r_vec >= r_cnt and o_vec > 0 and r_cnt > 0:
            log.info("Embeddings up-to-date: routines=%d/%d, objects=%d "
                     "(skipping rebuild)", r_vec, r_cnt, o_vec)
            return 0

    # Ensure subsystem map is populated (may be empty if metadata was already loaded)
    if not _subsystem_map:
        metadata_files = [
            f for f in os.listdir(METADATA_DIR)
            if f.endswith(".txt")
        ] if os.path.isdir(METADATA_DIR) else []
        if metadata_files:
            config = parse_metadata_report(os.path.join(METADATA_DIR, metadata_files[0]))
            _build_subsystem_map(config)
            log.info("Subsystem map rebuilt for embedding: %d entries",
                     sum(len(v) for v in _subsystem_map.values()))

    # --- Embed routines (streaming) ---
    rows = run_query("""
        MATCH (r:Routine {project_name: $p})
        OPTIONAL MATCH (m:Module)-[:DECLARES]->(r)
        RETURN r.id AS id, r.name AS name, r.signature AS signature,
               r.doc_description AS doc_description,
               r.params_text AS params_text,
               r.owner_qn AS owner_qn, r.export AS export,
               r.routine_type AS routine_type,
               r.directive AS directive,
               r.area_path AS area_path,
               r.doc_params_text AS doc_params_text,
               r.doc_return_text AS doc_return_text,
               m.module_type AS module_type
    """, {"p": PROJECT_NAME})

    # Pre-fetch called objects per routine (top 5 unique object names from CALLS targets)
    call_obj_map = {}
    call_rows = run_query("""
        MATCH (r:Routine {project_name: $p})-[:CALLS]->(target:Routine)
        RETURN r.id AS rid, target.owner_qn AS target_owner
    """, {"p": PROJECT_NAME})
    for cr in call_rows:
        t_parts = (cr.get("target_owner") or "").split("/")
        if len(t_parts) >= 4:
            obj_label = f"{t_parts[2]}.{t_parts[3]}"
            lst = call_obj_map.setdefault(cr["rid"], [])
            if obj_label not in lst and len(lst) < 5:
                lst.append(obj_label)

    embedded = 0
    embedded_o = 0

    if rows:
        total = len(rows)
        existing_hashes = store.get_all_hashes("routines")
        current_keys = set()
        pending_items: list[tuple[str, dict, str, str]] = []
        pending_texts: list[str] = []
        skipped = 0
        seen = 0

        def flush_routines():
            nonlocal embedded
            if not pending_texts:
                return
            inner = _adaptive_inner_batch(pending_texts)
            vectors = embedder.embed_passages(pending_texts, batch_size=inner)
            store.add_many("routines", pending_items, vectors)
            embedded += len(pending_texts)
            log.info("Embedded routines: %d/%d (skipped=%d, chunk=%d, inner_batch=%d)",
                     embedded + skipped, total, skipped, len(pending_texts), inner)
            pending_items.clear()
            pending_texts.clear()

        log.info("Embedding routines: total=%d, chunk=%d, model=e5-base",
                 total, EMBEDDING_STREAM_CHUNK)
        for r in rows:
            seen += 1
            key = r["id"]
            current_keys.add(key)
            r["_called_objects"] = call_obj_map.get(key, [])
            text = _build_routine_text(r)
            th = text_hash(text)
            if existing_hashes.get(key) == th:
                skipped += 1
                continue
            metadata = {
                "name": r.get("name", ""),
                "signature": r.get("signature", ""),
                "description": r.get("doc_description", ""),
                "owner_qn": r.get("owner_qn", ""),
                "export": r.get("export", False),
                "routine_type": r.get("routine_type", ""),
            }
            pending_items.append((key, metadata, th, text))
            pending_texts.append(text)
            if len(pending_items) >= EMBEDDING_STREAM_CHUNK:
                flush_routines()
        flush_routines()

        # Remove deleted routines
        removed = 0
        for old_key in set(existing_hashes) - current_keys:
            store.remove(old_key)
            removed += 1
        log.info("Routines done: total=%d, embedded=%d, unchanged=%d, removed=%d",
                 total, embedded, skipped, removed)

    # --- Embed metadata objects ---
    # Enriched text: Russian category + name + synonym + comment +
    # top-10 attributes + tabular parts + top-7 incoming references
    # (per edit_3/edit_4 — search_objects quality fix)
    obj_rows = run_query("""
        MATCH (mo:MetadataObject {project_name: $p})
        WHERE NOT mo.category_name IN [
            'ОбщиеКартинки', 'ЭлементыСтиля', 'Стили',
            'CommonPictures', 'StyleItems', 'Styles'
        ]
        RETURN mo.name AS name, mo.category_name AS category,
               mo.Synonym AS synonym, mo.Comment AS comment,
               mo.qualified_name AS qn
    """, {"p": PROJECT_NAME})

    category_ru = {
        "Справочники": "Справочник",
        "Документы": "Документ",
        "РегистрыСведений": "Регистр сведений",
        "РегистрыНакопления": "Регистр накопления",
        "РегистрыБухгалтерии": "Регистр бухгалтерии",
        "РегистрыРасчета": "Регистр расчёта",
        "Перечисления": "Перечисление",
        "Обработки": "Обработка",
        "Отчеты": "Отчёт",
        "ОбщиеМодули": "Общий модуль",
        "БизнесПроцессы": "Бизнес-процесс",
        "Задачи": "Задача системы",
        "Константы": "Константа",
        "ПланыВидовХарактеристик": "План видов характеристик",
        "ПланыСчетов": "План счетов",
        "ПланыВидовРасчета": "План видов расчёта",
        "ПланыОбмена": "План обмена",
        "ОбщиеКоманды": "Общая команда",
        "ОбщиеФормы": "Общая форма",
        "Подсистемы": "Подсистема",
        "Роли": "Роль",
    }

    # Pre-fetch: attributes (max 15), tabular parts, dimensions, resources,
    # incoming refs (max 7), outgoing refs (max 10), enum values (max 10),
    # forms, register recorders (MOVEMENTS_IN)
    attr_map = {}
    attr_rows = run_query("""
        MATCH (mo:MetadataObject {project_name: $p})-[:HAS_ATTRIBUTE]->(a:Attribute)
        RETURN mo.qualified_name AS qn, a.name AS name, a.Synonym AS synonym
    """, {"p": PROJECT_NAME})
    for ar in attr_rows:
        lst = attr_map.setdefault(ar["qn"], [])
        if len(lst) < 15:
            lst.append(ar.get("synonym") or ar["name"])

    tab_map = {}
    tab_rows = run_query("""
        MATCH (mo:MetadataObject {project_name: $p})-[:HAS_TABULAR_PART]->(t:TabularPart)
        RETURN mo.qualified_name AS qn, t.name AS name, t.Synonym AS synonym
    """, {"p": PROJECT_NAME})
    for tr in tab_rows:
        tab_map.setdefault(tr["qn"], []).append(tr.get("synonym") or tr["name"])

    dim_map = {}
    dim_rows = run_query("""
        MATCH (mo:MetadataObject {project_name: $p})-[:HAS_DIMENSION]->(d:Dimension)
        RETURN mo.qualified_name AS qn, d.name AS name, d.Synonym AS synonym
    """, {"p": PROJECT_NAME})
    for dr in dim_rows:
        dim_map.setdefault(dr["qn"], []).append(dr.get("synonym") or dr["name"])

    res_map = {}
    res_rows = run_query("""
        MATCH (mo:MetadataObject {project_name: $p})-[:HAS_RESOURCE]->(r:Resource)
        RETURN mo.qualified_name AS qn, r.name AS name, r.Synonym AS synonym
    """, {"p": PROJECT_NAME})
    for rr in res_rows:
        res_map.setdefault(rr["qn"], []).append(rr.get("synonym") or rr["name"])

    # Incoming refs (who references this object)
    ref_map = {}
    seen_ref = {}
    ref_rows = run_query("""
        MATCH (other:MetadataObject)-[:USED_IN]->(mo:MetadataObject {project_name: $p})
        RETURN mo.qualified_name AS qn, other.name AS name
    """, {"p": PROJECT_NAME})
    for rr in ref_rows:
        seen = seen_ref.setdefault(rr["qn"], set())
        if rr["name"] in seen:
            continue
        lst = ref_map.setdefault(rr["qn"], [])
        if len(lst) < 7:
            lst.append(rr["name"])
            seen.add(rr["name"])

    # Outgoing refs (what this object references)
    out_ref_map = {}
    seen_out_ref = {}
    out_ref_rows = run_query("""
        MATCH (mo:MetadataObject {project_name: $p})-[:USED_IN]->(target:MetadataObject)
        RETURN mo.qualified_name AS qn, target.name AS name,
               target.category_name AS cat
    """, {"p": PROJECT_NAME})
    for orr in out_ref_rows:
        seen = seen_out_ref.setdefault(orr["qn"], set())
        if orr["name"] in seen:
            continue
        lst = out_ref_map.setdefault(orr["qn"], [])
        if len(lst) < 10:
            cat_short = category_ru.get(orr.get("cat", ""), "")
            label = f"{cat_short}.{orr['name']}" if cat_short else orr["name"]
            lst.append(label)
            seen.add(orr["name"])

    enum_map = {}
    enum_rows = run_query("""
        MATCH (mo:MetadataObject {project_name: $p})-[:HAS_ENUM_VALUE]->(ev:EnumValue)
        RETURN mo.qualified_name AS qn, ev.name AS name, ev.Synonym AS synonym
    """, {"p": PROJECT_NAME})
    for er in enum_rows:
        lst = enum_map.setdefault(er["qn"], [])
        if len(lst) < 10:
            lst.append(er.get("synonym") or er["name"])

    # Forms
    form_map = {}
    form_rows = run_query("""
        MATCH (mo:MetadataObject {project_name: $p})-[:HAS_FORM]->(f:Form)
        RETURN mo.qualified_name AS qn, f.name AS name
    """, {"p": PROJECT_NAME})
    for fr in form_rows:
        form_map.setdefault(fr["qn"], []).append(fr["name"])

    # Register recorders (documents that make movements into this register)
    recorder_map = {}
    recorder_rows = run_query("""
        MATCH (doc:MetadataObject)-[:MOVEMENTS_IN]->(reg:MetadataObject {project_name: $p})
        RETURN reg.qualified_name AS qn, doc.name AS name
    """, {"p": PROJECT_NAME})
    for rcr in recorder_rows:
        recorder_map.setdefault(rcr["qn"], []).append(rcr["name"])

    # Top export routines per object (top 10 export procedures/functions)
    routine_map = {}
    routine_rows = run_query("""
        MATCH (mo:MetadataObject {project_name: $p})-[:HAS_MODULE]->(m:Module)-[:DECLARES]->(r:Routine)
        WHERE r.export = true
        RETURN mo.qualified_name AS qn, r.name AS name
    """, {"p": PROJECT_NAME})
    for rtr in routine_rows:
        lst = routine_map.setdefault(rtr["qn"], [])
        if len(lst) < 10:
            lst.append(rtr["name"])

    # Cross-enrichment: collect keywords from ALL routines that mention each object
    # in their doc_description (not just routines owned by that object)
    routine_desc_map = {}  # obj_name -> set of keywords
    all_routines_with_desc = run_query("""
        MATCH (r:Routine {project_name: $p})
        WHERE r.doc_description IS NOT NULL AND size(r.doc_description) > 15
        RETURN r.doc_description AS doc_desc
    """, {"p": PROJECT_NAME})
    # Build object name -> keywords from routines that mention it
    obj_name_set = {o.get("name", "") for o in obj_rows}
    for rd in all_routines_with_desc:
        desc = rd.get("doc_desc") or ""
        for obj_name in obj_name_set:
            if obj_name and len(obj_name) >= 5 and obj_name in desc:
                words = [w.strip().lower() for w in desc.split()
                         if len(w.strip()) >= 5 and w.strip().lower() != obj_name.lower()]
                kw_set = routine_desc_map.setdefault(obj_name, set())
                for w in words[:8]:
                    kw_set.add(w)
    if routine_desc_map:
        log.info("Cross-enrichment: %d objects enriched from routine descriptions",
                 len(routine_desc_map))

    # Purpose tag patterns: (category, name_regex) -> description
    import re as _re_purpose
    PURPOSE_PATTERNS = [
        ("РегистрыСведений", _re_purpose.compile(r"Цен", _re_purpose.IGNORECASE),
         "хранение цен и тарифов"),
        ("РегистрыСведений", _re_purpose.compile(r"Остат|Запас", _re_purpose.IGNORECASE),
         "учет остатков и запасов"),
        ("РегистрыСведений", _re_purpose.compile(r"Настро|Параметр", _re_purpose.IGNORECASE),
         "хранение настроек и параметров"),
        ("РегистрыСведений", _re_purpose.compile(r"Курс|Валют", _re_purpose.IGNORECASE),
         "хранение курсов валют"),
        ("РегистрыСведений", _re_purpose.compile(r"Штрих|Баркод|Barcode", _re_purpose.IGNORECASE),
         "хранение штрихкодов"),
        ("РегистрыСведений", _re_purpose.compile(r"Адрес", _re_purpose.IGNORECASE),
         "хранение адресов"),
        ("РегистрыНакопления", _re_purpose.compile(r"Товар.*Склад|Запас|Остат", _re_purpose.IGNORECASE),
         "складской учет товаров"),
        ("РегистрыНакопления", _re_purpose.compile(r"Взаиморасчет|Задолж|Расчет.*Контрагент", _re_purpose.IGNORECASE),
         "учет взаиморасчетов"),
        ("РегистрыНакопления", _re_purpose.compile(r"Продаж|Выручк", _re_purpose.IGNORECASE),
         "учет продаж и выручки"),
        ("РегистрыНакопления", _re_purpose.compile(r"Закупк|Поступлен", _re_purpose.IGNORECASE),
         "учет закупок"),
        ("Документы", _re_purpose.compile(r"Заказ.*Клиент|Заказ.*Покупат", _re_purpose.IGNORECASE),
         "оформление заказа от покупателя"),
        ("Документы", _re_purpose.compile(r"Заказ.*Поставщик", _re_purpose.IGNORECASE),
         "оформление заказа поставщику"),
        ("Документы", _re_purpose.compile(r"Реализац", _re_purpose.IGNORECASE),
         "оформление продажи покупателю"),
        ("Документы", _re_purpose.compile(r"Поступлен", _re_purpose.IGNORECASE),
         "оформление закупки у поставщика"),
        ("Документы", _re_purpose.compile(r"Оплат|Платеж|ПлатежноеПоручение", _re_purpose.IGNORECASE),
         "оформление оплаты"),
        ("Документы", _re_purpose.compile(r"Перемещен", _re_purpose.IGNORECASE),
         "перемещение товаров между складами"),
        ("Документы", _re_purpose.compile(r"Списан", _re_purpose.IGNORECASE),
         "списание товаров"),
        ("Документы", _re_purpose.compile(r"Инвентар", _re_purpose.IGNORECASE),
         "инвентаризация"),
        ("Документы", _re_purpose.compile(r"Счет.*Факт|СчетФакт", _re_purpose.IGNORECASE),
         "счет-фактура"),
        ("Документы", _re_purpose.compile(r"Авансовый.*Отчет|АвансовыйОтчет", _re_purpose.IGNORECASE),
         "авансовый отчет"),
        ("Справочники", _re_purpose.compile(r"Контрагент|Партнер", _re_purpose.IGNORECASE),
         "справочник юридических и физических лиц"),
        ("Справочники", _re_purpose.compile(r"Номенклатур", _re_purpose.IGNORECASE),
         "справочник товаров и услуг"),
        ("Справочники", _re_purpose.compile(r"Организац", _re_purpose.IGNORECASE),
         "справочник собственных организаций"),
        ("Справочники", _re_purpose.compile(r"Склад", _re_purpose.IGNORECASE),
         "справочник складов"),
        ("Справочники", _re_purpose.compile(r"Сотрудник|ФизическоеЛицо", _re_purpose.IGNORECASE),
         "справочник сотрудников"),
        ("Справочники", _re_purpose.compile(r"Договор", _re_purpose.IGNORECASE),
         "справочник договоров"),
        ("Справочники", _re_purpose.compile(r"Валют", _re_purpose.IGNORECASE),
         "справочник валют"),
        ("Справочники", _re_purpose.compile(r"ЕдиницыИзмерения|Единица", _re_purpose.IGNORECASE),
         "справочник единиц измерения"),
    ]

    _CATEGORY_FALLBACK_RU = {
        "Документы": "документ для",
        "Справочники": "справочник",
        "РегистрыСведений": "хранение данных о",
        "РегистрыНакопления": "учет",
        "РегистрыБухгалтерии": "бухгалтерский учет",
        "РегистрыРасчета": "расчёт",
        "Обработки": "инструмент для",
        "Отчеты": "отчет по",
        "Перечисления": "виды и типы",
        "БизнесПроцессы": "бизнес-процесс",
        "Задачи": "задача",
        "Константы": "настройка",
        "ПланыВидовХарактеристик": "план видов характеристик",
        "ПланыСчетов": "план счетов",
        "ПланыВидовРасчета": "план видов расчёта",
        "ПланыОбмена": "обмен данными",
    }

    def _infer_purpose_tag(obj_name: str, cat_raw: str, synonym: str) -> str:
        """Infer purpose tag from category + name pattern, or fallback."""
        for pat_cat, pat_re, tag in PURPOSE_PATTERNS:
            if cat_raw == pat_cat and pat_re.search(obj_name):
                return tag
        # Fallback: category prefix + synonym
        prefix = _CATEGORY_FALLBACK_RU.get(cat_raw, "")
        if prefix and synonym:
            return f"{prefix} {synonym.lower()}"
        return ""

    if obj_rows:
        total_obj = len(obj_rows)
        existing_obj_hashes = store.get_all_hashes("objects")
        current_obj_keys = set()
        pending_items_o: list[tuple[str, dict, str, str]] = []
        pending_texts_o: list[str] = []
        embedded_o = 0
        skipped_o = 0

        def flush_objects():
            nonlocal embedded_o
            if not pending_texts_o:
                return
            inner = _adaptive_inner_batch(pending_texts_o)
            vectors = embedder.embed_passages(pending_texts_o, batch_size=inner)
            store.add_many("objects", pending_items_o, vectors)
            embedded_o += len(pending_texts_o)
            log.info("Embedded objects: %d/%d (skipped=%d, chunk=%d, inner_batch=%d)",
                     embedded_o + skipped_o, total_obj, skipped_o,
                     len(pending_texts_o), inner)
            pending_items_o.clear()
            pending_texts_o.clear()

        log.info("Embedding metadata objects: total=%d, chunk=%d",
                 total_obj, EMBEDDING_STREAM_CHUNK)
        for o in obj_rows:
            key = o["qn"]
            current_obj_keys.add(key)
            name = o.get("name", "") or ""
            name_split = _split_camel_case(name)
            cat_raw = o.get("category", "") or ""
            cat = category_ru.get(cat_raw, cat_raw)
            synonym = o.get("synonym") or ""
            comment = o.get("comment") or ""

            # 1. Classification — FIRST, sets context
            parts = [f"Тип: {cat}"]

            # 2. Name and synonym
            parts.append(f"Имя: {name_split}")
            if synonym and synonym != name and synonym != _split_camel_case(name):
                parts.append(f"Синоним: {synonym}")

            # 3. Description
            if comment:
                parts.append(f"Описание: {comment}")

            # 4. Purpose tag (auto-inferred or from patterns)
            purpose = _infer_purpose_tag(name, cat_raw, synonym)
            if purpose:
                parts.append(f"Назначение: {purpose}")

            # 4b. Subsystem (from Состав property of subsystem objects)
            obj_subsystems = _subsystem_map.get(name, [])
            if obj_subsystems:
                parts.append("Подсистема: " + ", ".join(obj_subsystems))

            # 5. Dimensions (critical for registers)
            obj_dims = dim_map.get(key, [])
            if obj_dims:
                parts.append("Измерения: " + ", ".join(
                    _split_camel_case(d) for d in obj_dims))

            # 6. Resources (critical for registers)
            obj_res = res_map.get(key, [])
            if obj_res:
                parts.append("Ресурсы: " + ", ".join(
                    _split_camel_case(r) for r in obj_res))

            # 7. Attributes (top 15)
            obj_attrs = attr_map.get(key, [])
            if obj_attrs:
                parts.append("Реквизиты: " + ", ".join(
                    _split_camel_case(a) for a in obj_attrs))

            # 8. Tabular parts
            obj_tabs = tab_map.get(key, [])
            if obj_tabs:
                parts.append("Табличные части: " + ", ".join(
                    _split_camel_case(t) for t in obj_tabs))

            # 9. Enum values (top 10)
            obj_enums = enum_map.get(key, [])
            if obj_enums:
                parts.append("Значения: " + ", ".join(
                    _split_camel_case(e) for e in obj_enums))

            # 10. Outgoing references (what this object references)
            obj_out_refs = out_ref_map.get(key, [])
            if obj_out_refs:
                parts.append("Связан с: " + ", ".join(obj_out_refs))

            # 11. Incoming references (who references this object)
            obj_refs = ref_map.get(key, [])
            if obj_refs:
                parts.append("Используется в: " + ", ".join(
                    _split_camel_case(r) for r in obj_refs))

            # 12. Register recorders
            obj_recorders = recorder_map.get(key, [])
            if obj_recorders:
                parts.append("Регистраторы: " + ", ".join(
                    _split_camel_case(r) for r in obj_recorders))

            # 13. Forms
            obj_forms = form_map.get(key, [])
            if obj_forms:
                parts.append("Формы: " + ", ".join(
                    _split_camel_case(f) for f in obj_forms))

            # 14. Top export routines
            obj_routines = routine_map.get(key, [])
            if obj_routines:
                parts.append("Экспортные процедуры: " + ", ".join(
                    _split_camel_case(r) for r in obj_routines))

            # 15. Context keywords from routine descriptions (cross-enrichment)
            desc_kw = routine_desc_map.get(name, set())
            if desc_kw:
                # Filter out words already in parts text
                existing = " ".join(parts).lower()
                new_kw = [w for w in sorted(desc_kw) if w not in existing]
                if new_kw:
                    parts.append("Контекст: " + " ".join(new_kw[:15]))

            text = "\n".join(parts)
            th = text_hash(text)

            if existing_obj_hashes.get(key) == th:
                skipped_o += 1
                continue
            metadata = {
                "name": o.get("name", ""),
                "category": o.get("category", ""),
                "synonym": o.get("synonym", ""),
                "comment": o.get("comment", ""),
            }
            pending_items_o.append((key, metadata, th, text))
            pending_texts_o.append(text)
            if len(pending_items_o) >= EMBEDDING_STREAM_CHUNK:
                flush_objects()
        flush_objects()

        removed_o = 0
        for old_key in set(existing_obj_hashes) - current_obj_keys:
            store.remove(old_key)
            removed_o += 1
        log.info("Objects done: total=%d, embedded=%d, unchanged=%d, removed=%d",
                 total_obj, embedded_o, skipped_o, removed_o)

    total_embedded = embedded + embedded_o
    log.info("Embedding complete: %d routines, %d objects in vector store (embedded this run: %d)",
             store.count("routines"), store.count("objects"), total_embedded)
    return total_embedded


def load_all():
    """Main entry point — load all data for this project."""
    log.info("=" * 60)
    log.info("Starting data load for project: %s", PROJECT_NAME)
    log.info("=" * 60)

    ensure_indexes()

    # Check if data already exists
    if not FULL_METADATA_RELOAD and _project_data_exists():
        result = run_query(
            "MATCH (n:MetadataObject {project_name: $name}) RETURN count(n) AS cnt",
            {"name": PROJECT_NAME},
        )
        cnt = result[0]["cnt"] if result else 0
        log.info("[OK] Project metadata already loaded (%d objects)", cnt)
        # Build embeddings if enabled (models + sqlite-vec + vectors)
        embedded_count = 0
        if ENABLE_EMBEDDING:
            embedded_count = _build_embeddings() or 0
        return embedded_count

    if FULL_METADATA_RELOAD:
        _clear_project()

    # 1. Parse metadata report
    metadata_files = [
        f for f in os.listdir(METADATA_DIR)
        if f.endswith(".txt")
    ] if os.path.isdir(METADATA_DIR) else []

    if not metadata_files:
        log.warning("No metadata files found in %s", METADATA_DIR)
        return

    config = parse_metadata_report(os.path.join(METADATA_DIR, metadata_files[0]))
    _load_metadata(config)

    # 2. Parse ConfigDumpInfo.xml for GUIDs
    dump_file = os.path.join(CODE_DIR, "ConfigDumpInfo.xml")
    if os.path.exists(dump_file):
        guid_map = parse_config_dump(dump_file)
        _load_guid_map(guid_map)

    # 3. BSL routines
    routines = []
    if LOAD_BSL_SIGNATURES and os.path.isdir(CODE_DIR):
        routines = scan_bsl_files(CODE_DIR, PROJECT_NAME, config.config_name)
        if routines:
            _load_routines(routines)

    # 4. Forms
    if LOAD_FORMS_FROM_XML and os.path.isdir(CODE_DIR):
        forms = scan_forms(CODE_DIR, PROJECT_NAME, config.config_name)
        if forms:
            _load_forms(forms)

    # 5. Predefined
    if LOAD_PREDEFINED_VALUES and os.path.isdir(CODE_DIR):
        predefined = scan_predefined(CODE_DIR, PROJECT_NAME, config.config_name)
        if predefined:
            _load_predefined(predefined)

    # 6. Roles
    if LOAD_ROLE_RIGHTS and os.path.isdir(CODE_DIR):
        grants = scan_roles(CODE_DIR, PROJECT_NAME, config.config_name)
        if grants:
            _load_roles(grants, config.config_name)

    # 7. Build USED_IN relationships from type references
    _build_used_in()

    # 7b. Build USED_IN from BSL code references
    if routines:
        _build_code_used_in(routines)

    # 7c. Build MOVEMENTS_IN from document module code
    if routines:
        _build_movements(routines)

    # 8. Build embeddings (optional)
    embedded_count = 0
    if ENABLE_EMBEDDING:
        embedded_count = _build_embeddings() or 0

    # Final stats
    stats = run_query("""
        MATCH (n) WHERE n.project_name = $name
        RETURN labels(n)[0] AS label, count(n) AS cnt
        ORDER BY cnt DESC
    """, {"name": PROJECT_NAME})
    log.info("Load complete. Stats:")
    for s in stats:
        log.info("  %s: %d", s["label"], s["cnt"])
    return embedded_count
