using System;
using System.Collections.Generic;

namespace BystrUmApp
{
    public class ChildProfile
    {
        public string Nickname { get; set; } = "Артём";
        public int Age { get; set; } = 6;
        public int Level { get; set; } = 3;
        public int StarsCount { get; set; } = 14;
        public int ExperiencePoints { get; set; } = 360;

        public void AddRewards(int stars, int xp)
        {
            StarsCount += stars;
            ExperiencePoints += xp;
            if (ExperiencePoints >= Level * 150)
            {
                Level++;
            }
        }

        public void DisplayProfileInfo()
        {
            Console.WriteLine($"[Профиль игрока]: {Nickname}, {Age} лет | Уровень: {Level} | Звёзды: ★ {StarsCount} | Опыт: {ExperiencePoints} XP");
        }
    }

    public class AccessibilitySettings
    {
        public bool GameSoundsEnabled { get; set; } = true;
        public bool BackgroundMusicEnabled { get; set; } = false;

        public bool ReduceMotion { get; set; } = true;
        public bool PlayWithoutTimer { get; set; } = true;

        public int SessionDurationMinutes { get; set; } = 15;
        public bool BreakReminderEnabled { get; set; } = true;

        public void DisplaySettings()
        {
            Console.WriteLine("--- Родительские настройки доступности ---");
            Console.WriteLine($"Звуки игры: {(GameSoundsEnabled ? "Включены (мягкие звуки)" : "Выключены")}");
            Console.WriteLine($"Фоновая музыка: {(BackgroundMusicEnabled ? "Включена" : "Выключена (игра в тишине)")}");
            Console.WriteLine($"Спокойный режим (уменьшить анимацию): {(ReduceMotion ? "Включено" : "Выключено")}");
            Console.WriteLine($"Игра без таймера: {(PlayWithoutTimer ? "Включено (без ограничений)" : "Выключено (с таймером)")}");
            Console.WriteLine($"Длительность занятия: {SessionDurationMinutes} мин | Напоминать о перерыве: {(BreakReminderEnabled ? "Да" : "Нет")}");
        }
    }

    public class Achievement
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public bool IsUnlocked { get; set; }

        public Achievement(string title, string description, string category, bool isUnlocked)
        {
            Title = title;
            Description = description;
            Category = category;
            IsUnlocked = isUnlocked;
        }
    }

    public class AchievementService
    {
        private readonly List<Achievement> _achievements = new();

        public AchievementService()
        {
            _achievements.Add(new Achievement("Друг чисел", "За 1 игру с числами", "Математический спринт", true));
            _achievements.Add(new Achievement("Кубок счёта", "За 5 игр с числами", "Математический спринт", false));

            _achievements.Add(new Achievement("Зоркий глаз", "За 1 игру на поиск", "Поиск лишнего", true));
            _achievements.Add(new Achievement("Кубок внимания", "За 5 игр на поиск", "Поиск лишнего", false));

            _achievements.Add(new Achievement("Первые пары", "За 1 игру с парами", "Логические пары", true));
            _achievements.Add(new Achievement("Кубок логики", "За 5 игр с парами", "Логические пары", false));
        }

        public void Unlock(string title)
        {
            var ach = _achievements.Find(a => a.Title == title);
            if (ach != null && !ach.IsUnlocked)
            {
                ach.IsUnlocked = true;
                Console.WriteLine($"[НОВАЯ НАГРАДА РАЗБЛОКИРОВАНА]: {ach.Title} ({ach.Category})");
            }
        }

        public void DisplayCollection()
        {
            Console.WriteLine("--- Мои достижения и кубки ---");
            Console.WriteLine("«Ты учишься и растёшь! Играй в своём темпе. Новые кубки подождут.»");
            foreach (var item in _achievements)
            {
                string status = item.IsUnlocked ? "[✓ Получено]" : "[Впереди]";
                Console.WriteLine($"  {status} {item.Title} ({item.Category}): {item.Description}");
            }
        }
    }

    public class GameSessionResult
    {
        public string GameTitle { get; set; } = string.Empty;
        public int TotalTasks { get; set; }
        public int CorrectAnswers { get; set; }
        public double AverageReactionTimeMs { get; set; }
        public int EarnedStars { get; set; }
        public int EarnedXP { get; set; }
    }

    public class GameEngine
    {
        public GameSessionResult PlayMathSprint(AccessibilitySettings settings)
        {
            Console.WriteLine("\n[Запуск мини-игры]: Математический спринт (Играй с числами)");
            if (settings.PlayWithoutTimer)
            {
                Console.WriteLine("Режим: Без таймера (комфортный темп для ребенка)");
            }

            int tasksCount = 3;
            int correct = 3;
            double reactionMs = 760.0;

            Console.WriteLine($"Выполнено заданий: {tasksCount}/{tasksCount}");
            Console.WriteLine($"Точность: 100% | Зафиксированная скорость реакции: {reactionMs:F0} мс");

            return new GameSessionResult
            {
                GameTitle = "Математический спринт",
                TotalTasks = tasksCount,
                CorrectAnswers = correct,
                AverageReactionTimeMs = reactionMs,
                EarnedStars = 3,
                EarnedXP = 50
            };
        }
    }

    class Program
    {
        static void Main()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.WriteLine("=== Прототип программной системы «БыстрУм» ===");

            var profile = new ChildProfile();
            var settings = new AccessibilitySettings();
            var achievements = new AchievementService();
            var engine = new GameEngine();

            profile.DisplayProfileInfo();
            Console.WriteLine();

            settings.DisplaySettings();
            Console.WriteLine();

            achievements.DisplayCollection();

            var session = engine.PlayMathSprint(settings);

            profile.AddRewards(session.EarnedStars, session.EarnedXP);
            achievements.Unlock("Кубок счёта");

            Console.WriteLine("\n--- Итоги раунда ---");
            Console.WriteLine($"Получено звёзд: +{session.EarnedStars} ★ | Опыт: +{session.EarnedXP} XP");
            profile.DisplayProfileInfo();
        }
    }
}
