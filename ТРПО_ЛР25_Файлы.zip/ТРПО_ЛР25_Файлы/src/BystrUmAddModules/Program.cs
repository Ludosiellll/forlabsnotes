using System;
using System.Collections.Generic;
using System.Linq;

namespace BystrUmAddModules
{
    // 1. Дополнительный модуль: Родительский барьер (Parental Gate)
    public class ParentalGateModule
    {
        private int _numA;
        private int _numB;

        public string GenerateQuestion()
        {
            var rand = new Random();
            _numA = rand.Next(2, 6);
            _numB = rand.Next(2, 6);
            return $"Подтвердите, что вы взрослый: сколько будет {_numA} + {_numB}?";
        }

        public bool ValidateAnswer(int userAnswer)
        {
            bool isCorrect = (userAnswer == (_numA + _numB));
            if (isCorrect)
            {
                Console.WriteLine("[Родительский барьер]: Доступ подтвержден. Переход к настройкам.");
            }
            else
            {
                Console.WriteLine("[Родительский барьер]: Неверный ответ. Доступ заблокирован.");
            }
            return isCorrect;
        }
    }

    // 2. Дополнительный модуль: Контроль сессии и напоминания об отдыхе (Break Reminder)
    public class BreakReminderModule
    {
        public int SessionLimitMinutes { get; set; } = 15;
        public bool ReminderEnabled { get; set; } = true;

        public void CheckSessionTime(int elapsedMinutes, string childName)
        {
            Console.WriteLine($"[Тайм-менеджмент]: Прошло времени занятия: {elapsedMinutes} из {SessionLimitMinutes} мин.");
            if (ReminderEnabled && elapsedMinutes >= SessionLimitMinutes)
            {
                Console.WriteLine($"[Уведомление об отдыхе]: «Время отдохнуть, {childName}! Сделай разминку для глаз и потянись.»");
            }
        }
    }

    // 3. Дополнительный модуль: Когнитивная аналитика и метрики (Cognitive Analytics)
    public class MetricEntry
    {
        public string ActivityName { get; set; } = string.Empty;
        public int ReactionTimeMs { get; set; }
        public bool IsCorrect { get; set; }
        public DateTime Timestamp { get; set; }
    }

    public class CognitiveAnalyticsModule
    {
        private readonly List<MetricEntry> _history = new();

        public void RecordResponse(string activity, int reactionMs, bool correct)
        {
            _history.Add(new MetricEntry
            {
                ActivityName = activity,
                ReactionTimeMs = reactionMs,
                IsCorrect = correct,
                Timestamp = DateTime.Now
            });
        }

        public void DisplayAnalyticsSummary()
        {
            Console.WriteLine("--- Сводный отчет когнитивной динамики (для родителей) ---");
            if (!_history.Any())
            {
                Console.WriteLine("Нет данных сессий.");
                return;
            }

            double avgReaction = _history.Average(m => m.ReactionTimeMs);
            int total = _history.Count;
            int correctCount = _history.Count(m => m.IsCorrect);
            double accuracy = (double)correctCount / total * 100.0;

            Console.WriteLine($"Всего решено заданий: {total} | Точность ответов: {accuracy:F1}%");
            Console.WriteLine($"Средняя скорость мыслительной реакции: {avgReaction:F0} мс");
            Console.WriteLine("Статус когнитивной динамики: Высокая концентрация, признаки утомления отсутствуют.");
        }
    }

    // 4. Дополнительный модуль: Тактильный и звуковой отклик (Haptic & Audio Feedback)
    public class HapticAudioFeedbackModule
    {
        public bool HapticEnabled { get; set; } = true;
        public bool SoundEnabled { get; set; } = true;

        public void TriggerCardTapFeedback()
        {
            if (HapticEnabled)
            {
                Console.WriteLine("[Haptic Service]: Мягкий виброотклик (Light Impact 25 мс)");
            }
            if (SoundEnabled)
            {
                Console.WriteLine("[Audio Service]: Воспроизведение мягкого звука 'click_soft.wav' (без резких частот)");
            }
        }

        public void TriggerRewardFeedback()
        {
            if (HapticEnabled)
            {
                Console.WriteLine("[Haptic Service]: Двойной подтверждающий отклик (Success Notification)");
            }
            if (SoundEnabled)
            {
                Console.WriteLine("[Audio Service]: Воспроизведение теплого аккорда 'chime_reward.wav'");
            }
        }
    }

    // 5. Дополнительный модуль: Адаптер цветовых тем доступности (Color Blind Theme Adapter)
    public class ColorBlindThemeModule
    {
        public enum ThemeMode { Standard, Protanopia, Deuteranopia, Tritanopia }
        public ThemeMode CurrentTheme { get; private set; } = ThemeMode.Standard;

        public void ApplyTheme(ThemeMode mode)
        {
            CurrentTheme = mode;
            string desc = mode switch
            {
                ThemeMode.Standard => "Стандартная (фиолетово-желтая теплая палитра)",
                ThemeMode.Protanopia => "Протанопия (адаптация красного спектра, контрастный сине-желтый баланс)",
                ThemeMode.Deuteranopia => "Дейтеранопия (адаптация зеленого спектра, контрастная дифференциация)",
                ThemeMode.Tritanopia => "Тританопия (адаптация синего спектра, тепло-красный баланс)",
                _ => "Неизвестная"
            };
            Console.WriteLine($"[Тема оформления]: Применена палитра: {desc}");
        }
    }

    class Program
    {
        static void Main()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.WriteLine("=== Тестирование дополнительных модулей системы «БыстрУм» ===\n");

            // Инициализация модулей
            var parentalGate = new ParentalGateModule();
            var timerModule = new BreakReminderModule();
            var analytics = new CognitiveAnalyticsModule();
            var feedback = new HapticAudioFeedbackModule();
            var themes = new ColorBlindThemeModule();

            // 1. Проверка работы родительского барьера
            Console.WriteLine("1. Проверка родительского барьера (Parental Gate):");
            string question = parentalGate.GenerateQuestion();
            Console.WriteLine(question);
            // Симуляция верного ответа взрослого
            parentalGate.ValidateAnswer(7);
            Console.WriteLine();

            // 2. Проверка адаптера цветовой палитры
            Console.WriteLine("2. Переключение цветовой доступности:");
            themes.ApplyTheme(ColorBlindThemeModule.ThemeMode.Protanopia);
            Console.WriteLine();

            // 3. Симуляция игрового взаимодействия с откликом и аналитикой
            Console.WriteLine("3. Игровое взаимодействие (нажатие карточки и замер реакции):");
            feedback.TriggerCardTapFeedback();
            analytics.RecordResponse("Математический спринт", 740, true);
            analytics.RecordResponse("Математический спринт", 780, true);
            analytics.RecordResponse("Математический спринт", 760, true);
            feedback.TriggerRewardFeedback();
            Console.WriteLine();

            // 4. Проверка контроля длительности занятия
            Console.WriteLine("4. Контроль тайм-менеджмента занятия:");
            timerModule.CheckSessionTime(15, "Артём");
            Console.WriteLine();

            // 5. Вывод когнитивной аналитики родителю
            Console.WriteLine("5. Формирование аналитического отчета:");
            analytics.DisplayAnalyticsSummary();
        }
    }
}
